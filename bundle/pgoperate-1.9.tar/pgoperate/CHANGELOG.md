
systemctl stop postgresql-pg13.service
systemctl disable postgresql-pg13.service
rm /etc/systemd/system/postgresql-pg13.service
systemctl daemon-reload

/var/lib/pgsql/tvdtoolbox/pgoperate/bin/root.sh


vi parameters_pg13.conf
copy new parameters
set INTENDED_STATE=UP

